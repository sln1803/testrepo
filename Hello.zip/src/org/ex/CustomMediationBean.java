package org.ex;

import com.capeclear.mediation.MediationContext;
import com.capeclear.assembly.annotation.Component;
import static com.capeclear.assembly.annotation.Component.Type.customMediation;;

/**
 * Custom mediation.
 *
 * TODO Modify the Component annotation. Also add Property annotations to any
 * bean pattern methods you add and want to appear in the Assembly Editor.
 */
@Component(
        name = "CustomMediationBean",
        type = customMediation,
        toolTip = "",
        scope = "prototype",
        smallIconPath = "icons/CustomMediationBean_16.png",
        largeIconPath = "icons/CustomMediationBean_24.png"
        )
public class CustomMediationBean {

	/**
	 * Called during the request or 'push' phase of Assembly processing.  
	 */
    public void request(MediationContext context) {
        // TODO: implementation
    }

	/**
	 * Called during the response or 'pop' phase of Assembly processing.  
	 */
    public void response(MediationContext context) {
        // TODO: implementation
    }
    
}